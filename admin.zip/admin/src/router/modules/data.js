/** When your routing table is too long, you can split it into small modules**/

import Layout from '@/layout'

const DataRouter = {
  path: '/data',
  component: Layout,
  redirect: 'data',
  meta: {title: '数据统计', icon: 'international'},
  children: [
    {
      path: 'data/index',
      component: () => import('@/views/data/index'),
      name: 'data',
      meta: {title: '门店统计', icon: 'international'}
    },
    {
      path: 'order/:id(\\d+)',
      component: () => import('@/views/data/order'),
      name: 'data/detail',
      meta: {title: '店铺订单', noCache: true, activeMenu: '/recruit/list'},
      hidden: true
    },

    {
      path: 'goods/:id(\\d+)',
      component: () => import('@/views/data/goods'),
      name: 'goods',
      meta: {title: '店铺商品', noCache: true, activeMenu: '/recruit/list'},
      hidden: true
    },

  ]
}
export default DataRouter
