/** When your routing table is too long, you can split it into small modules **/

import Layout from '@/layout'

const DistRouter = {
  path: '/distribution',
  component: Layout,
  redirect: 'distribution',
  name: 'distribution',
  meta: {
    title: '用户管理',
    icon: 'component'
  },
  children: [
    {
      path: 'index',
      component: () => import('@/views/distribution/index'),
      name: 'distribution',
      meta: {title: '用户管理'}
    },
    {
      path: 'apply',
      component: () => import('@/views/distribution/apply'),
      name: 'apply',
      meta: {title: '分销申请'}
    },
    // {
    //   path: 'distorder',
    //   component: () => import('@/views/distribution/order'),
    //   name: 'distorder',
    //   meta: {title: '分销订单'}
    // },
    // {
    //   path: 'withdrawal',
    //   component: () => import('@/views/distribution/withdrawal'),
    //   name: 'withdrawal',
    //   meta: {title: '申请提现'}
    // },
  ]
}

export default DistRouter
