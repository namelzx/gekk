/** When your routing table is too long, you can split it into small modules**/

import Layout from '@/layout'

const OrderRouter = {
  path: '/order',
  component: Layout,
  redirect: 'order',
  meta: {title: '订单管理', icon: 'international'},
  children: [
    {
      path: '/index',
      component: () => import('@/views/order/index'),
      name: 'order',
      meta: {title: '订单管理', icon: 'international'}
    },
    {
      path: 'detail/:id(\\d+)',
      component: () => import('@/views/order/detail'),
      name: 'detail',
      meta: {title: '查看订单详细', noCache: true, activeMenu: '/recruit/list'},
      hidden: true
    },
  ]
}
export default OrderRouter
