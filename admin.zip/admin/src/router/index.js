import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/* Router Modules */

import DistRouter from './modules/distribution'
import IntegralRouter from './modules/Integral'
import OrderRouter from "./modules/order";


/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [

  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/auth-redirect',
    component: () => import('@/views/login/auth-redirect'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/error-page/404'),
    hidden: true
  },
  {
    path: '/401',
    component: () => import('@/views/error-page/401'),
    hidden: true
  },
  {
    path: '',
    component: Layout,
    redirect: 'dashboard',
    children: [
      {
        path: 'dashboard',
        component: () => import('@/views/dashboard/index'),
        name: 'Dashboard',
        meta: { title: 'dashboard', icon: 'dashboard', affix: true }
      }
    ]
  },
  {
    path: '/apps',
    component: Layout,
    redirect: 'apps',
    meta: { title: '商铺管理', icon: 'international' },
    children: [
      {
        path: 'apps',
        component: () => import('@/views/apps/index'),
        name: 'apps',
        meta: { title: '商铺管理', icon: 'international' }
      },
      {
        path: 'createapps',
        component: () => import('@/views/apps/createapps'),
        name: 'createapps',
        meta: { title: '添加商铺', icon: 'international' }
      },
      {
        path: 'edit/:id(\\d+)',
        component: () => import('@/views/apps/editapps'),
        name: 'editapps',
        hidden: true,
        meta: { title: '编辑商铺', icon: 'international' }
      }
    ]
  }

]

/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 */
export const asyncRoutes = [

  /** when your routing map is too long, you can split it into small modules **/

  // tableRouter,
  DistRouter,
  IntegralRouter,
  OrderRouter,

  {
    path: '/i18n',
    component: Layout,
    children: [
      {
        path: 'index',
        component: () => import('@/views/i18n-demo/index'),
        name: 'I18n',
        meta: { title: 'i18n', icon: 'international' }
      }
    ]
  },

  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
