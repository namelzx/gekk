import Vue from 'vue'
import Router from 'vue-router'
/* Layout */
import Layout from '@/layout'
import DistRouter from './modules/distribution'
import IntegralRouter from './modules/Integral'
import OrderRouter from "./modules/order";
import DataRouter from "./modules/data";

Vue.use(Router)

/* Router Modules */


/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [

  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/auth-redirect',
    component: () => import('@/views/login/auth-redirect'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/error-page/404'),
    hidden: true
  },
  {
    path: '/401',
    component: () => import('@/views/error-page/401'),
    hidden: true
  },
  {
    path: '',
    component: Layout,
    redirect: 'dashboard',
    children: [
      {
        path: 'dashboard',
        component: () => import('@/views/dashboard/index'),
        name: 'Dashboard',
        meta: {title: 'dashboard', icon: 'dashboard', affix: true}
      }
    ]
  },
  {
    path: '/apps',
    component: Layout,
    redirect: 'apps',
    meta: {title: '商铺管理', icon: 'international'},
    children: [
      {
        path: 'apps',
        component: () => import('@/views/apps/index'),
        name: 'apps',
        meta: {title: '商铺管理', icon: 'international'}
      },
      {
        path: 'createapps',
        component: () => import('@/views/apps/createapps'),
        name: 'createapps',
        meta: {title: '添加商铺', icon: 'international'}
      },
      {
        path: 'edit/:id(\\d+)',
        component: () => import('@/views/apps/editapps'),
        name: 'editapps',
        hidden: true,
        meta: {title: '编辑商铺', icon: 'international'}
      }
    ]
  },

  {
    path: '/category',
    component: Layout,
    redirect: 'category',
    meta: {title: '商品分类', icon: 'international'},
    children: [
      {
        path: 'apps',
        component: () => import('@/views/category/index'),
        name: 'apps',
        meta: {title: '平台商品分类', icon: 'international'}
      },
    ]
  },


]

/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 */
export const asyncRoutes = [

  /** when your routing map is too long, you can split it into small modules **/

  // tableRouter,
  DistRouter,
  IntegralRouter,
  OrderRouter,
  DataRouter,
  {
    path: '/banner',
    component: Layout,
    redirect: 'banner',
    meta: {title: '轮播主题', icon: 'international'},
    children: [
      {
        path: 'banner',
        component: () => import('@/views/banner/index'),
        name: 'banner',
        meta: {title: '主题列表', icon: 'international'}
      },
      {
        path: 'wx',
        component: () => import('@/views/config/wx'),
        name: 'wx',
        meta: {title: '微信配置', icon: 'international'}
      },

    ]
  },

  {
    path: '/config',
    component: Layout,
    redirect: 'config',
    meta: {title: '系统配置', icon: 'international'},
    children: [
      {
        path: 'sms',
        component: () => import('@/views/config/index'),
        name: 'sms',
        meta: {title: '短信配置', icon: 'international'}
      },
      {
        path: 'wx',
        component: () => import('@/views/config/wx'),
        name: 'wx',
        meta: {title: '微信配置', icon: 'international'}
      },
      {
        path: 'plat',
        component: () => import('@/views/plat/index'),
        name: 'plat',
        meta: {title: '平台配置', icon: 'international'}
      },

    ]
  },


  {path: '*', redirect: '/404', hidden: true}
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({y: 0}),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
