import request from '@/utils/request'


export function GetDataByList(data) {
  return request({
    url: '/dist/GetDataByList',
    method: 'get',
    params: data
  })
}



export function PostDataBySave(data) {
  return request({
    url: '/dist/PostDataBySave',
    method: 'post',
    data
  })
}



