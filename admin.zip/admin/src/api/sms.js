import request from '@/utils/request'


export function GetSmsByInfo(data) {
  return request({
    url: '/Sms/GetSmsByInfo',
    method: 'get',
    params: data
  })
}



export function PostDataBySave(data) {
  return request({
    url: '/Sms/PostDataBySave',
    method: 'post',
    data
  })
}



