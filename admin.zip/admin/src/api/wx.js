import request from '@/utils/request'


export function GetWxByInfo(data) {
  return request({
    url: '/wx/GetWxByInfo',
    method: 'get',
    params: data
  })
}


export function PostDataBySave(data) {
  return request({
    url: '/wx/PostDataBySave',
    method: 'post',
    data
  })
}



