import request from '@/utils/request'

export function GetShopByList() {
  return request({
    url: '/GetShopByList',
    method: 'get',

  })
}



