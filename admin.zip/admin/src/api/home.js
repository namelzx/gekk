import request from '@/utils/request'

export function GetHomeByData() {
  return request({
    url: '/GetHomeByData',
    method: 'get',
  })
}
