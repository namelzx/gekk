import request from '@/utils/request'


export function GetPlatByInfo(data) {
  return request({
    url: '/plat/GetPlatByInfo',
    method: 'get',
    params: data
  })
}


export function PostDataBySave(data) {
  return request({
    url: '/plat/PostDataBySave',
    method: 'post',
    data
  })
}



