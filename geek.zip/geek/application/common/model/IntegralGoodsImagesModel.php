<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-29
 * Time: 13:19
 */

namespace app\common\model;


class IntegralGoodsImagesModel extends BaseModel
{
    protected $table = 'ee_integral_goods_images';


}