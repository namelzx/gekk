<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-29
 * Time: 00:52
 */

namespace app\common\model;


class IntegralLogModel extends BaseModel
{
    protected $table = 'ee_integral_log';
    protected $createTime = 'create_time';

}