<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-29
 * Time: 17:16
 */

namespace app\common\model;


class IntegralOrderModel extends BaseModel
{

    protected $table = 'ee_integral_order';
    protected $createTime = 'create_time';
}