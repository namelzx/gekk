<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-29
 * Time: 13:20
 */

namespace app\common\model;


class IntegralGoodsSukModel extends BaseModel
{
    protected $table='ee_integral_goods_suk';

}