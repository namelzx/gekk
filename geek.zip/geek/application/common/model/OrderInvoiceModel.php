<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-22
 * Time: 18:56
 */

namespace app\common\model;


class OrderInvoiceModel extends BaseModel
{
    protected $table = 'ee_order_invoice';

}