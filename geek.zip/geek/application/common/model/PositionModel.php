<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-17
 * Time: 23:04
 */

namespace app\common\model;


class PositionModel extends BaseModel
{
    protected $table = 'ee_position';

}