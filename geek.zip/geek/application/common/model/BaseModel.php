<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-09
 * Time: 21:24
 */

namespace app\common\model;


use think\Model;

class BaseModel extends Model
{

}