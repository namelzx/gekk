<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-12
 * Time: 12:37
 */

namespace app\common\model;


class GoodsSukModel extends BaseModel
{
    protected $table = 'ee_goods_suk';

}