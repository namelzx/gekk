<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-29
 * Time: 17:18
 */

namespace app\common\model;


class IntegralOrderGoodsModel extends BaseModel
{
    protected $table = 'ee_integral_order_goods';
    

}