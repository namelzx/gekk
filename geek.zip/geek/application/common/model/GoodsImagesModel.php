<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-16
 * Time: 20:08
 */

namespace app\common\model;


class GoodsImagesModel extends BaseModel
{
    protected $table = 'ee_goods_images';

}