<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-09-10
 * Time: 22:18
 */

namespace app\admin\controller;


class Category extends Base
{

}