// pages/goods/fee/index.js
Component({
  options:{
    styleIsolation: 'apply-shared'
  },
  properties:{
    noPostFee: {
      type: Boolean
    },
    detailed:{
      type:Object
    }
  }
})