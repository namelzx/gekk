// pages/goods/swiper/index.js
Component({
  options:{
    styleIsolation: 'apply-shared'
  },
  properties:{
    swiperImg:{
      type: Array
    }
  },
  data: {

  },
})