// pages/goods/footer/index.js
Component({
  options:{
    styleIsolation:'apply-shared'
  },
  properties:{
    cart:{
      type: Number
    }
  }
})