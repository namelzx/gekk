// pages/goods/ratings/index.js
Component({
  options:{
    styleIsolation:'apply-shared'
  },
  properties:{
    ratings: {
      type: Array
    },
    eavcout:Number,
    eavnumber:Number,
  }
})