// pages/home/vip/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    vipList:[
      {
        id:'1',
        vip_url: './../../../static/images/vip-level-1.png',
        vip_text:'&购物9.2折'
      },
      {
        id: '2',
        vip_url: './../../../static/images/vip-level-2.png',
        vip_text: '&购物9.2折'
      },
      {
        id: '3',
        vip_url: './../../../static/images/vip-level-3.png',
        vip_text: '&购物9.2折'
      },
      {
        id: '4',
        vip_url: './../../../static/images/vip-level-4.png',
        vip_text: '&购物9.2折'
      },
      {
        id: '5',
        vip_url: './../../../static/images/vip-level-5.png',
        vip_text: '&购物9.2折'
      },
      {
        id: '6',
        vip_url: './../../../static/images/vip-level-6.png',
        vip_text: '&购物9.2折'
      },
      {
        id: '7',
        vip_url: './../../../static/images/vip-level-7.png',
        vip_text: '&购物9.2折'
      },
      {
        id: '8',
        vip_url: './../../../static/images/vip-level-8.png',
        vip_text: '&购物9.2折'
      },
      
    ]
  },
})