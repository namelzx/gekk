const config = {
  api_blink_url: 'https://hhh.10huisp.com/api/app/',
  api_images_url: 'https://www.youtirp.com/',
}

export { config }