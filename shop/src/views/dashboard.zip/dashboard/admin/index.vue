<template>
  <div class="dashboard-editor-container">
    <panel-group />
    <real-time />
  </div>
</template>

<script>
import PanelGroup from "./components/PanelGroup";
import RealTime from "./components/RealTime";
export default {
  name: "DashboardAdmin",
  components: {
    PanelGroup,
    RealTime
  },
  data() {
    return {};
  },
  methods: {}
};
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 0 32px;
  background-color: #fff;
  position: relative;

  .github-corner {
    position: absolute;
    top: 0px;
    border: 0;
    right: 0;
  }

  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
}
</style>
